import 'dart:convert';
import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:http_parser/http_parser.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:seaofsea/services/v1/auth_service.dart';
import 'package:seaofsea/utils/auth_provider.dart';
import 'package:seaofsea/utils/secure_storage.dart';
import 'v1_config.dart';

class V1ApiManager {
  final String baseUrl;
  final SecureStorage _storage = SecureStorage();
  String? deviceUUID;

  V1ApiManager({this.baseUrl = V1Config.baseUrl});

  Future<void> _initDeviceUUID() async {
    deviceUUID ??= await _storage.readSecureData('deviceUUID');
  }

  Future<String> _getDeviceName() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      if (Platform.isAndroid) {
        final info = await deviceInfo.androidInfo;
        return '${info.manufacturer} ${info.model}';
      } else if (Platform.isIOS) {
        final info = await deviceInfo.iosInfo;
        return '${info.name} ${info.model}';
      } else if (Platform.isWindows) {
        final info = await deviceInfo.windowsInfo;
        return 'Windows ${info.computerName}';
      } else if (Platform.isMacOS) {
        final info = await deviceInfo.macOsInfo;
        return 'Mac ${info.model}';
      } else if (Platform.isLinux) {
        final info = await deviceInfo.linuxInfo;
        return 'Linux ${info.prettyName}';
      }
    } catch (e) {
      debugPrint('⚠️ _getDeviceName error: $e');
    }
    return 'Unknown Device';
  }

  String _getPlatformName() => Platform.operatingSystem;
  String _getOSVersion() => Platform.operatingSystemVersion;

  Future<String> _getAppVersion() async {
    try {
      final info = await PackageInfo.fromPlatform();
      return '${info.version}+${info.buildNumber}';
    } catch (_) {
      return 'unknown';
    }
  }

  Future<Map<String, dynamic>> getDeviceParams() async {
    await _initDeviceUUID();
    return {
      'device_uuid': deviceUUID,
      'device_name': await _getDeviceName(),
      'platform': _getPlatformName(),
      'os_version': _getOSVersion(),
      'app_version': await _getAppVersion(),
    };
  }

  Future<Map<String, dynamic>> call({
    required String module,
    required String action,
    Map<String, dynamic>? params,
    bool requiresAuth = true,
    File? file,
    String? fileType,
    String? fileName,
    void Function(double progress)? onProgress,
  }) async {
    final dio = Dio();
    final uri = '$baseUrl/v1/index.php';

    debugPrint("🔗 API Call: working");
    await _initDeviceUUID();
    String? token;

    if (requiresAuth) {
      final rawToken = await _storage.readSecureData('authToken');

      if (rawToken == null || rawToken.isEmpty) {
        await AuthProvider.instance.v1logout();
        return _unauthorizedResponse('User not logged in.');
      }

      if (_isTokenExpired(rawToken)) {
        final refreshResult = await AuthService().refreshToken();
        token = refreshResult?['token'];

        if (token == null || token.isEmpty) {
          await AuthProvider.instance.v1logout();
          return _unauthorizedResponse('Session expired. Please log in again.');
        }

        await _storage.writeSecureData('authToken', token);
      } else {
        token = rawToken;
      }

      if (token.isEmpty) {
        await AuthProvider.instance.v1logout();
        return _unauthorizedResponse('Authentication token is missing.');
      }
    }

    final fullParams = {
      ...?params,
      ...await getDeviceParams(),
    };

    final headers = {
      if (requiresAuth) 'Authorization': 'Bearer $token',
    };

    try {
      Response response;

      if (file != null) {
        final formData = FormData.fromMap({
          'module': module,
          'action': action,
          ...fullParams,
          'file': await MultipartFile.fromFile(
            file.path,
            filename: fileName ?? file.path.split('/').last,
            contentType: fileType != null ? MediaType.parse(fileType) : null,
          ),
        });

        response = await dio.post(
          uri,
          data: formData,
          options: Options(headers: headers, contentType: 'multipart/form-data'),
          onSendProgress: (sent, total) => onProgress?.call(sent / total),
        );
        debugPrint("Multi: ${response.data}");
      } else {
        response = await dio.post(
          uri,
          data: {
            'module': module,
            'action': action,
            'params': fullParams,
          },
          options: Options(
            headers: {
              ...headers,
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
          ),
        );
        debugPrint("Json: ${response.data}");
      }

      final decoded = response.data;
      return {
        'success': decoded['success'] == true,
        'message': decoded['message'] ?? '',
        'data': decoded['data'],
        'code': response.statusCode,
      };
    } on DioException catch (e) {
      return {
        'success': false,
        'message': e.response?.data['message'] ?? 'Connection error: ${e.message}',
        'data': null,
        'code': e.response?.statusCode,
      };
    }
  }

  Map<String, dynamic> _unauthorizedResponse(String message) => {
        'success': false,
        'message': message,
        'code': 401,
        'data': null,
      };

  bool _isTokenExpired(String token) {
    try {
      final parts = token.split('.');
      if (parts.length != 3) return true;

      final payload =
          utf8.decode(base64Url.decode(base64Url.normalize(parts[1])));
      final payloadMap = json.decode(payload);
      final exp = payloadMap['exp'];

      if (exp == null) return true;

      final expiryDate = DateTime.fromMillisecondsSinceEpoch(exp * 1000);
      return DateTime.now().isAfter(expiryDate);
    } catch (_) {
      return true;
    }
  }
}
