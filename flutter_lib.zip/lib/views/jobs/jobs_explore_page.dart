import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:seaofsea/services/v1/v1_api_manager.dart';
import 'package:seaofsea/widgets/custon_scaffold.dart';

class JobsExplorePage extends StatefulWidget {
  const JobsExplorePage({super.key});

  @override
  State<JobsExplorePage> createState() => _JobsExplorePageState();
}

class _JobsExplorePageState extends State<JobsExplorePage> {
  final _scroll = ScrollController();
  final _searchCtrl = TextEditingController();

  List<Map<String, dynamic>> _items = [];
  bool _loading = true;
  bool _loadingMore = false;
  bool _hasMore = true;

  int _page = 1;
  final int _perPage = 20;
  String? _q;
  bool _cvOnly = false; // skeleton: backend destekliyorsa 'cv_match' paramı ile

  @override
  void initState() {
    super.initState();
    _fetch(reset: true);
    _scroll.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scroll.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (!_hasMore || _loadingMore || _loading) return;
    if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 400) {
      _fetch();
    }
  }

  Future<void> _fetch({bool reset = false}) async {
    if (reset) {
      setState(() {
        _page = 1;
        _items = [];
        _hasMore = true;
        _loading = true;
      });
    } else {
      setState(() => _loadingMore = true);
    }

    try {
      final v1 = context.read<V1ApiManager>();
      final res = await v1.call(
        module: 'companyjob',
        action: 'search',
        params: {
          'status': 'open',
          'visibility': 'public',
          if (_q != null && _q!.isNotEmpty) 'q': _q,
          if (_cvOnly) 'cv_match': 1, // backend destekliyorsa
          'page': _page,
          'perPage': _perPage,
        },
      );

      final data = res['data'];
      List raw;
      int total;
      if (data is Map) {
        raw = (data['items'] ?? data['jobs'] ?? data['results'] ?? []) as List;
        final t = data['total'];
        total = t is int ? t : int.tryParse('$t') ?? raw.length;
      } else if (data is List) {
        raw = data;
        total = raw.length;
      } else {
        raw = const [];
        total = 0;
      }

      final pageItems = raw
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();

      setState(() {
        _items.addAll(pageItems);
        _page++;
        _hasMore = _items.length < total;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Load error: $e')),
        );
      }
    } finally {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _loadingMore = false;
      });
    }
  }

  void _onSearch() {
    _q = _searchCtrl.text.trim();
    _fetch(reset: true);
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      title: 'Jobs',
      body: Column(
        children: [
          // Filters bar
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchCtrl,
                    decoration: const InputDecoration(
                      hintText: 'Search jobs, company, location…',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.search),
                      isDense: true,
                    ),
                    onSubmitted: (_) => _onSearch(),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton.icon(
                  onPressed: _onSearch,
                  icon: const Icon(Icons.search),
                  label: const Text('Search'),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
            child: Row(
              children: [
                FilterChip(
                  selected: _cvOnly,
                  label: const Text('CV’ye uygun'),
                  onSelected: (v) {
                    setState(() => _cvOnly = v);
                    _fetch(reset: true);
                  },
                ),
                const SizedBox(width: 8),
                TextButton.icon(
                  onPressed: () => _fetch(reset: true),
                  icon: const Icon(Icons.refresh),
                  label: const Text('Refresh'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : RefreshIndicator(
                    onRefresh: () => _fetch(reset: true),
                    child: ListView.separated(
                      controller: _scroll,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 8),
                      itemCount:
                          _items.length + (_loadingMore || _hasMore ? 1 : 0),
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        if (i >= _items.length) {
                          // loader row
                          return Padding(
                            padding: const EdgeInsets.all(16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: const [
                                SizedBox(
                                    width: 18,
                                    height: 18,
                                    child: CircularProgressIndicator(
                                        strokeWidth: 2)),
                                SizedBox(width: 12),
                                Text('Loading…'),
                              ],
                            ),
                          );
                        }

                        final j = _items[i];
                        final id =
                            int.tryParse('${j['id'] ?? j['job_id'] ?? 0}') ?? 0;
                        final title = (j['title'] ?? 'Untitled').toString();
                        final companyName =
                            (j['company_name'] ?? j['company'] ?? '')
                                .toString();
                        final companyId =
                            int.tryParse('${j['company_id'] ?? 0}') ?? 0;
                        final location =
                            (j['location'] ?? j['city'] ?? '').toString();
                        final createdAt = (j['created_at'] ?? '').toString();

                        return ListTile(
                          title: Text(title),
                          subtitle: Text([
                            if (companyName.isNotEmpty) companyName,
                            if (location.isNotEmpty) '• $location',
                            if (createdAt.isNotEmpty) '• $createdAt',
                          ].join('  ')),
                          trailing: OutlinedButton(
                            onPressed: id <= 0
                                ? null
                                : () {
                                    Navigator.pushNamed(
                                      context,
                                      '/job_application',
                                      arguments: {
                                        'job_id': id,
                                        if (companyId > 0)
                                          'company_id': companyId,
                                        if (companyName.isNotEmpty)
                                          'company_name': companyName,
                                      },
                                    );
                                  },
                            child: const Text('Apply'),
                          ),
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
