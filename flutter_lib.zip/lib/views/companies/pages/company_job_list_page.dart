import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:seaofsea/services/v1/job_service.dart';
import 'package:seaofsea/services/v1/v1_api_manager.dart';
import 'package:seaofsea/utils/permission_gate.dart';
import 'package:seaofsea/widgets/custon_scaffold.dart';

class CompanyJobListPage extends StatefulWidget {
  final int companyId;
  final String? initialStatus;

  const CompanyJobListPage({
    super.key,
    required this.companyId,
    this.initialStatus,
  });

  @override
  State<CompanyJobListPage> createState() => _CompanyJobListPageState();
}

class _CompanyJobListPageState extends State<CompanyJobListPage> {
  late final JobService _jobs;

  // UI state
  final _scroll = ScrollController();
  final _searchCtrl = TextEditingController();
  Timer? _debounce;

  // filters
  final _statuses = const ['open', 'draft', 'closed', 'archived'];
  String _status = 'open';
  String _q = '';

  // paging
  final int _perPage = 20;
  int _page = 1;
  bool _loading = false;
  bool _hasMore = true;

  // data
  final List<Map<String, dynamic>> _items = [];
  int _total = 0;

  @override
  void initState() {
    super.initState();
    _jobs = JobService(context.read<V1ApiManager>());
    _status = widget.initialStatus ?? 'open';

    _scroll.addListener(_onScroll);
    _searchCtrl.addListener(_onSearchChanged);

    // initial load
    WidgetsBinding.instance.addPostFrameCallback((_) => _load(reset: true));
  }

  @override
  void dispose() {
    _scroll.removeListener(_onScroll);
    _scroll.dispose();
    _debounce?.cancel();
    _searchCtrl.removeListener(_onSearchChanged);
    _searchCtrl.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () {
      setState(() => _q = _searchCtrl.text.trim());
      _load(reset: true);
    });
  }

  void _onScroll() {
    if (!_hasMore || _loading) return;
    final pos = _scroll.position;
    if (pos.pixels + 300 >= pos.maxScrollExtent) {
      _load();
    }
  }

  Future<void> _load({bool reset = false}) async {
    if (_loading) return;
    setState(() => _loading = true);

    try {
      if (reset) {
        _page = 1;
        _hasMore = true;
        _items.clear();
      }

      final data = await _jobs.search(
        q: _q.isEmpty ? null : _q,
        companyId: widget.companyId,
        status: _status,
        page: _page,
        perPage: _perPage,
      );

      // normalize
      final rawItems =
          (data['items'] ?? data['jobs'] ?? []) as List? ?? const [];
      final total = int.tryParse('${data['total'] ?? rawItems.length}') ??
          rawItems.length;

      _items.addAll(rawItems.cast<Map<String, dynamic>>());
      _total = total;

      // paging flags
      _hasMore = rawItems.length >= _perPage;
      if (_hasMore) _page += 1;
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Load failed: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _refresh() => _load(reset: true);

  void _apply(Map<String, dynamic> j) {
    final jobId = (j['id'] is int)
        ? j['id'] as int
        : int.tryParse('${j['id'] ?? 0}') ?? 0;
    if (jobId <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invalid job')),
      );
      return;
    }
    Navigator.pushNamed(
      context,
      '/job_application',
      arguments: {
        'job_id': jobId,
        'company_id': widget.companyId,
        'company_name':
            (j['company_name'] ?? j['companyTitle'] ?? '').toString(),
      },
    );
  }

  Future<void> _closeJob(Map<String, dynamic> j) async {
    final jobId = (j['id'] is int)
        ? j['id'] as int
        : int.tryParse('${j['id'] ?? 0}') ?? 0;
    if (jobId <= 0) return;

    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Close job?'),
        content: const Text('This will close the job to new applications.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Close')),
        ],
      ),
    );
    if (ok != true) return;

    try {
      await _jobs.close(jobId);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Job closed')),
        );
        _refresh();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Close failed: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      title: 'Open Jobs',
      actions: [
        PermissionGate(
          permissionCode: 'job.create',
          companyId: widget.companyId,
          wait: false,
          child: Padding(
            padding: const EdgeInsets.only(right: 8),
            child: FilledButton.icon(
              onPressed: () async {
                final created = await Navigator.pushNamed(
                  context,
                  '/job_editor',
                  arguments: {'company_id': widget.companyId},
                );
                if (created == true) _refresh();
              },
              icon: const Icon(Icons.add),
              label: const Text('New Job'),
            ),
          ),
        ),
      ],
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: Column(
          children: [
            // Filters
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _searchCtrl,
                      decoration: const InputDecoration(
                        hintText: 'Search jobs…',
                        prefixIcon: Icon(Icons.search),
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  DropdownButton<String>(
                    value: _status,
                    items: _statuses
                        .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                        .toList(),
                    onChanged: (v) {
                      if (v == null) return;
                      setState(() => _status = v);
                      _load(reset: true);
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),

            // List
            Expanded(
              child: _items.isEmpty && !_loading
                  ? const Center(child: Text('No jobs found'))
                  : ListView.separated(
                      controller: _scroll,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 8),
                      itemCount: _items.length + (_hasMore || _loading ? 1 : 0),
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        if (i >= _items.length) {
                          // loader tail
                          return const Padding(
                            padding: EdgeInsets.symmetric(vertical: 16),
                            child: Center(child: CircularProgressIndicator()),
                          );
                        }
                        final j = _items[i];
                        final title = (j['title'] ?? 'Untitled').toString();
                        final createdAt = (j['created_at'] ?? '').toString();
                        final location =
                            (j['location'] ?? j['city'] ?? '').toString();
                        final applicants = int.tryParse(
                                '${j['app_count'] ?? j['applications'] ?? 0}') ??
                            0;
                        final status = (j['status'] ?? '').toString();

                        return ListTile(
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          title: Text(title,
                              style:
                                  const TextStyle(fontWeight: FontWeight.w600)),
                          subtitle: Text([
                            if (location.isNotEmpty) location,
                            if (status.isNotEmpty) '• $status',
                            if (createdAt.isNotEmpty) '• $createdAt',
                          ].join('  ')),
                          trailing: Wrap(
                            spacing: 6,
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              const Icon(Icons.people_alt_outlined, size: 18),
                              Text('$applicants'),
                              const SizedBox(width: 6),
                              OutlinedButton(
                                onPressed: () => _apply(j),
                                child: const Text('Apply'),
                              ),
                              // Yönetim aksiyonları (step 4’te genişletilecek)
                              PermissionGate(
                                permissionCode: 'job.manage',
                                companyId: widget.companyId,
                                child: PopupMenuButton<String>(
                                  tooltip: 'Manage',
                                  itemBuilder: (_) => const [
                                    PopupMenuItem(
                                        value: 'edit', child: Text('Edit')),
                                    PopupMenuItem(
                                        value: 'close', child: Text('Close')),
                                  ],
                                  onSelected: (v) async {
                                    final jobId =
                                        int.tryParse('${j['id'] ?? 0}') ?? 0;
                                    if (v == 'close') _closeJob(j);
                                    if (v == 'edit') {
                                      final updated = await Navigator.pushNamed(
                                        context,
                                        '/job_editor',
                                        arguments: {
                                          'company_id': widget.companyId,
                                          'job_id': jobId
                                        },
                                      );
                                      if (updated == true) _refresh();
                                    }
                                  },
                                ),
                              ),
                            ],
                          ),
                          onTap: () {
                            // İleride iş detay sayfasına gidebiliriz
                          },
                        );
                      },
                    ),
            ),

            // Footer info
            if (!_loading && _items.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Text('Showing ${_items.length} of $_total'),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
