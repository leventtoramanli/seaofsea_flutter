import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:seaofsea/services/v1/job_service.dart';
import 'package:seaofsea/services/v1/v1_api_manager.dart';
import 'package:seaofsea/widgets/custon_scaffold.dart';

class JobApplicationPage extends StatefulWidget {
  final int? jobId; // ← başvuru bu ID üzerinden
  final int? companyId; // opsiyonel (başlık / geri dönüş için)
  final String? companyName;

  const JobApplicationPage({
    super.key,
    this.jobId,
    this.companyId,
    this.companyName,
  });

  @override
  State<JobApplicationPage> createState() => _JobApplicationPageState();
}

class _JobApplicationPageState extends State<JobApplicationPage> {
  late final JobService _jobs;
  final _msgCtrl = TextEditingController();

  bool _loading = true;
  bool _submitting = false;
  Map<String, dynamic>? _job; // başlık, konum vs. göstermek için

  @override
  void initState() {
    super.initState();
    _jobs = JobService(context.read<V1ApiManager>());
    _init();
  }

  @override
  void dispose() {
    _msgCtrl.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    setState(() => _loading = true);
    try {
      if (widget.jobId != null) {
        final d = await _jobs.detail(widget.jobId!);
        final row = (d['item'] is Map)
            ? Map<String, dynamic>.from(d['item'])
            : Map<String, dynamic>.from(d);
        _job = row;
      }
    } catch (_) {
      _job = null;
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _submit() async {
    if (widget.jobId == null || widget.jobId! <= 0) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Invalid job')));
      return;
    }
    setState(() => _submitting = true);
    try {
      await _jobs.apply(
        jobId: widget.jobId!,
        message: _msgCtrl.text.trim().isEmpty ? null : _msgCtrl.text.trim(),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Application submitted')),
      );
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('❌ $e')),
      );
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  void _openMyCv() {
    // TODO: sende hangi rota ise ona yönlendir.
    // Örn: Navigator.pushNamed(context, '/edit_cv');
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Open CV page: set route here')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final titleSuffix =
        widget.companyName != null ? ' — ${widget.companyName}' : '';
    final jobTitle = (_job?['title'] ?? '').toString();

    return CustomScaffold(
      title: 'Job Application$titleSuffix',
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16),
              child: ListView(
                children: [
                  if (jobTitle.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Text(
                        jobTitle,
                        style: Theme.of(context)
                            .textTheme
                            .titleLarge
                            ?.copyWith(fontWeight: FontWeight.w700),
                      ),
                    ),
                  Row(
                    children: [
                      OutlinedButton.icon(
                        onPressed: _openMyCv,
                        icon: const Icon(Icons.description_outlined),
                        label: const Text('Show my CV'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _msgCtrl,
                    maxLines: 5,
                    decoration: const InputDecoration(
                      labelText: 'Application Message (optional)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 24),
                  FilledButton.icon(
                    onPressed: _submitting ? null : _submit,
                    icon: _submitting
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.send),
                    label: Text(_submitting ? 'Sending…' : 'Apply'),
                  ),
                ],
              ),
            ),
    );
  }
}
