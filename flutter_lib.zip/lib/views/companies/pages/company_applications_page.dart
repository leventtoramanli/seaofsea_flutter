import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:seaofsea/views/companies/dashboard/services/applications_service.dart';
import 'package:seaofsea/services/v1/v1_api_manager.dart';
import 'package:seaofsea/utils/permission_gate.dart';
import 'package:seaofsea/utils/permission_provider.dart';
import 'package:seaofsea/views/companies/dashboard/models/application.dart';
import 'package:seaofsea/widgets/custon_scaffold.dart';

class CompanyApplicationsPage extends StatefulWidget {
  final int companyId;
  final String? initialStatus;

  const CompanyApplicationsPage(
      {super.key, required this.companyId, this.initialStatus});

  @override
  State<CompanyApplicationsPage> createState() =>
      _CompanyApplicationsPageState();
}

class _CompanyApplicationsPageState extends State<CompanyApplicationsPage> {
  late final ApplicationsServiceV1 _svc;
  final _statuses = const [
    'submitted',
    'under_review',
    'shortlisted',
    'interview',
    'offer',
    'hired',
    'rejected',
    'withdrawn'
  ];

  String? _statusFilter;
  String? _search;
  int _page = 1;
  int _perPage = 25;
  bool _loading = false;
  String? _error;
  PagedResult<Application>? _data;

  @override
  void initState() {
    super.initState();
    _svc = ApplicationsServiceV1(api: context.read<V1ApiManager>());
    _statusFilter = widget.initialStatus;
    _fetch();
  }

  Future<void> _fetch() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final res = await _svc.getCompanyApplications(
        companyId: widget.companyId,
        statuses: _statusFilter != null ? [_statusFilter!] : null,
        page: _page,
        perPage: _perPage,
        search: _search,
        orderBy: 'created_at_desc',
      );
      setState(() {
        _data = res;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
      });
    } finally {
      if (mounted)
        setState(() {
          _loading = false;
        });
    }
  }

  void _onSearch(String v) {
    _search = v.trim().isEmpty ? null : v.trim();
    _page = 1;
    _fetch();
  }

  void _onChangeStatus(String? st) {
    _statusFilter = st;
    _page = 1;
    _fetch();
  }

  @override
  Widget build(BuildContext context) {
    final canManage = PermissionProvider.of(context, listen: true).can(
        'application.manage'); // genel kısa yol; butonlarda Gate de kullanacağız
    final companyId = widget.companyId;

    return CustomScaffold(
      title: 'Job Applications',
      actions: [
        PermissionGate(
          permissionCode: 'application.manage',
          companyId: companyId, // sayfadaki mevcut değişkenin
          child: FilledButton.icon(
            icon: const Icon(Icons.add),
            label: const Text('New Application'),
            onPressed: () {
              Navigator.pushNamed(
                context,
                '/job_application',
                arguments: {'company_id': companyId},
              );
            },
          ),
        ),
      ],
      body: Column(
        children: [
          _FiltersBar(
            statuses: _statuses,
            selected: _statusFilter,
            onSelected: _onChangeStatus,
            onSearch: _onSearch,
          ),
          if (_loading)
            const Expanded(child: Center(child: CircularProgressIndicator())),
          if (!_loading && _error != null)
            Expanded(child: Center(child: Text('Error: $_error'))),
          if (!_loading && _error == null)
            Expanded(
              child: ListView.separated(
                itemCount: _data?.items.length ?? 0,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, index) {
                  final a = _data!.items[index];
                  return _ApplicationTile(
                    app: a,
                    companyId: widget.companyId,
                    onChanged: _fetch,
                    canManage: canManage,
                  );
                },
              ),
            ),
          if (!_loading && _data != null)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: _Pager(
                page: _data!.page,
                perPage: _data!.perPage,
                total: _data!.total,
                onPage: (p) {
                  setState(() => _page = p);
                  _fetch();
                },
              ),
            ),
        ],
      ),
    );
  }
}

class _FiltersBar extends StatefulWidget {
  final List<String> statuses;
  final String? selected;
  final void Function(String? st) onSelected;
  final void Function(String query) onSearch;

  const _FiltersBar({
    required this.statuses,
    required this.selected,
    required this.onSelected,
    required this.onSearch,
  });

  @override
  State<_FiltersBar> createState() => _FiltersBarState();
}

class _FiltersBarState extends State<_FiltersBar> {
  final _ctrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 1,
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ChoiceChip(
                  label: const Text('All'),
                  selected: widget.selected == null,
                  onSelected: (_) => widget.onSelected(null),
                ),
                ...widget.statuses.map((s) => ChoiceChip(
                      label: Text(s),
                      selected: widget.selected == s,
                      onSelected: (_) => widget.onSelected(s),
                    ))
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.search),
                      hintText: 'Search candidate / job / note',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: widget.onSearch,
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: () => widget.onSearch(_ctrl.text),
                  icon: const Icon(Icons.search),
                  label: const Text('Search'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ApplicationTile extends StatelessWidget {
  final Application app;
  final int companyId;
  final VoidCallback onChanged;
  final bool canManage;

  const _ApplicationTile({
    required this.app,
    required this.companyId,
    required this.onChanged,
    required this.canManage,
  });

  @override
  Widget build(BuildContext context) {
    final title = app.jobTitle ?? 'Job #${app.jobPostId ?? '-'}';
    final subtitle = '${app.candidateName ?? ''} ${app.candidateSurname ?? ''}'
            .trim()
            .isEmpty
        ? 'User #${app.userId}'
        : '${app.candidateName ?? ''} ${app.candidateSurname ?? ''}';
    final when = app.createdAt.toLocal().toString().split('.').first;

    return ListTile(
      title: Text(title),
      subtitle: Text('$subtitle • ${app.status} • $when'),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // DETAY: application.view
          PermissionGate(
            permissionCode: 'application.view',
            companyId: companyId,
            child: IconButton(
              icon: const Icon(Icons.remove_red_eye),
              tooltip: 'View',
              onPressed: () {
                // TODO: navigate to detail page (ApplicationDetailPage)
                // Navigator.pushNamed(context, '/company_application_detail', arguments: app.id);
              },
            ),
          ),
          // DURUM: application.manage
          PermissionGate(
            permissionCode: 'application.manage',
            companyId: companyId,
            child: PopupMenuButton<String>(
              icon: const Icon(Icons.swap_horiz),
              tooltip: 'Move status',
              onSelected: (to) async {
                final svc =
                    ApplicationsServiceV1(api: context.read<V1ApiManager>());
                final ok =
                    await svc.moveStatus(applicationId: app.id, toStatus: to);
                if (ok) onChanged();
              },
              itemBuilder: (ctx) => const [
                PopupMenuItem(
                    value: 'under_review', child: Text('Under review')),
                PopupMenuItem(value: 'shortlisted', child: Text('Shortlisted')),
                PopupMenuItem(value: 'interview', child: Text('Interview')),
                PopupMenuItem(value: 'offer', child: Text('Offer')),
                PopupMenuItem(value: 'hired', child: Text('Hired')),
                PopupMenuItem(value: 'rejected', child: Text('Rejected')),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Pager extends StatelessWidget {
  final int page;
  final int perPage;
  final int total;
  final void Function(int page) onPage;

  const _Pager({
    required this.page,
    required this.perPage,
    required this.total,
    required this.onPage,
  });

  @override
  Widget build(BuildContext context) {
    final pages = (total / perPage).ceil().clamp(1, 999999);
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        IconButton(
            onPressed: page > 1 ? () => onPage(page - 1) : null,
            icon: const Icon(Icons.chevron_left)),
        Text('Page $page / $pages'),
        IconButton(
            onPressed: page < pages ? () => onPage(page + 1) : null,
            icon: const Icon(Icons.chevron_right)),
      ],
    );
  }
}
