import 'package:seaofsea/services/v1/v1_api_manager.dart';
import 'package:seaofsea/views/companies/dashboard/models/application.dart';

class PagedResult<T> {
  final List<T> items;
  final int page;
  final int perPage;
  final int total;

  PagedResult(
      {required this.items,
      required this.page,
      required this.perPage,
      required this.total});
}

class ApplicationsServiceV1 {
  final V1ApiManager _api;
  ApplicationsServiceV1({V1ApiManager? api}) : _api = api ?? V1ApiManager();

  // --- List by company (with filters)
  Future<PagedResult<Application>> getCompanyApplications({
    required int companyId,
    List<String>? statuses,
    int? jobPostId,
    int page = 1,
    int perPage = 25,
    String? search,
    String? orderBy, // ops: created_at desc vs.
  }) async {
    final res = await _api.call(
      module: 'application',
      action: 'list_by_company',
      params: {
        'company_id': companyId,
        'page': page,
        'perPage': perPage,
        if (statuses != null && statuses.isNotEmpty) 'statuses': statuses,
        if (jobPostId != null) 'job_post_id': jobPostId,
        if (search != null && search.trim().isNotEmpty) 'q': search.trim(),
        if (orderBy != null) 'order_by': orderBy,
      },
    );

    if (res['success'] == true) {
      final d = res['data'] ?? res; // router sarımı
      final items = (d['items'] as List? ?? [])
          .map((e) => Application.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      final pageNum = int.tryParse('${d['page'] ?? page}') ?? page;
      final per = int.tryParse('${d['perPage'] ?? perPage}') ?? perPage;
      final total = int.tryParse('${d['total'] ?? 0}') ?? 0;
      return PagedResult<Application>(
          items: items, page: pageNum, perPage: per, total: total);
    }
    return PagedResult<Application>(
        items: [], page: page, perPage: perPage, total: 0);
  }

  Future<Application?> getDetail(int applicationId) async {
    final res = await _api.call(
      module: 'application',
      action: 'detail',
      params: {'application_id': applicationId},
    );
    if (res['success'] == true) {
      final d = res['data'] ?? res;
      final row = d['item'] ?? d; // handler item/d düzeltmesi
      if (row is Map) {
        return Application.fromJson(Map<String, dynamic>.from(row));
      }
    }
    return null;
  }

  Future<bool> moveStatus({
    required int applicationId,
    required String toStatus,
    String? note,
  }) async {
    final res = await _api.call(
      module: 'application',
      action: 'move_status',
      params: {
        'application_id': applicationId,
        'to_status': toStatus,
        if (note != null) 'note': note
      },
    );
    return res['success'] == true;
  }

  Future<bool> assignReviewer(
      {required int applicationId, required int reviewerUserId}) async {
    final res = await _api.call(
      module: 'application',
      action: 'assign_reviewer',
      params: {'application_id': applicationId, 'assigned_to': reviewerUserId},
    );
    return res['success'] == true;
  }

  Future<bool> addNote(
      {required int applicationId, required String note}) async {
    final res = await _api.call(
      module: 'application',
      action: 'add_note',
      params: {'application_id': applicationId, 'note': note},
    );
    return res['success'] == true;
  }

  Future<List<TimelineItem>> getTimeline(int applicationId) async {
    final res = await _api.call(
      module: 'application',
      action: 'time_line', // timeline alias'ını eklemiştin
      params: {'application_id': applicationId},
    );
    if (res['success'] == true) {
      final d = res['data'] ?? res;
      final list = (d['items'] as List? ?? []);
      return list
          .map((e) => TimelineItem.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    }
    return [];
  }

  // --- Candidate flow (şimdiden ekleyelim)
  Future<bool> createApplication({
    required int companyId,
    required int jobPostId,
    String? coverLetter,
    Map<String, dynamic>? cvSnapshot,
    List<dynamic>? attachments,
  }) async {
    final res = await _api.call(
      module: 'application',
      action: 'create',
      params: {
        'company_id': companyId,
        'job_post_id': jobPostId,
        if (coverLetter != null) 'cover_letter': coverLetter,
        if (cvSnapshot != null) 'cv_snapshot': cvSnapshot,
        if (attachments != null) 'attachments': attachments,
      },
    );
    return res['success'] == true;
  }

  Future<bool> withdraw(int applicationId) async {
    final res = await _api.call(
      module: 'application',
      action: 'withdraw',
      params: {'application_id': applicationId},
    );
    return res['success'] == true;
  }

  // --- Basit sayım (dashboard sayaçları için hızlı çözüm)
  Future<Map<String, int>> getCountsByStatus(int companyId) async {
    const statuses = [
      'submitted',
      'under_review',
      'shortlisted',
      'interview',
      'offer',
      'hired',
      'rejected',
      'withdrawn'
    ];
    final Map<String, int> out = {};
    for (final st in statuses) {
      final pr = await getCompanyApplications(
          companyId: companyId, statuses: [st], perPage: 1, page: 1);
      out[st] = pr.total;
    }
    return out;
  }

  Future<Map<String, dynamic>> create({
    required int companyId,
    required int jobPostId,
    int? userId, // başkası adına oluşturmak istersen
    String? coverLetter,
    String? status, // opsiyonel, 'submitted' default
  }) async {
    return await _api.call(
      module: 'application',
      action: 'create',
      params: {
        'company_id': companyId,
        'job_post_id': jobPostId,
        if (userId != null) 'user_id': userId,
        if (coverLetter != null) 'cover_letter': coverLetter,
        if (status != null) 'status': status,
      },
    );
  }
}
