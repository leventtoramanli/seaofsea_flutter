import 'dart:io';

import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:seaofsea/utils/api_manager.dart';
import 'package:seaofsea/views/companies/compny_list_page.dart';
import 'package:seaofsea/widgets/custom_image_picker.dart';
import 'package:seaofsea/widgets/custon_scaffold.dart';

class CreateCompanyPage extends StatefulWidget {
  const CreateCompanyPage({super.key});

  @override
  State<CreateCompanyPage> createState() => _CreateCompanyPageState();
}

class _CreateCompanyPageState extends State<CreateCompanyPage> {
  File? _companyLogo;
  Map<String, dynamic> infoData = {};
  bool isUpdating = false;
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _rankController = TextEditingController();
  bool _isLoading = false;
  String? _error;

  void _onImagePicked(File? file, String? base64, String type) async {
    final apiManager = Provider.of<ApiManager>(context, listen: false);
    final companyId = infoData['id'];

    if (file != null && companyId != null) {
      await apiManager.uploadImage(
        context,
        endpoint: 'company_logo',
        file: file,
        meta: {'type': type, 'company_id': companyId.toString()},
      );
    }
  }

  Future<void> _submitCompany() async {
    if (_nameController.text.trim().isEmpty ||
        _emailController.text.trim().isEmpty) {
      setState(() => _error = 'Company name and email cannot be empty.');
      return;
    }
    if (EmailValidator.validate(_emailController.text.trim()) == false) {
      setState(() => _error = 'Email is not valid.');
      return;
    }

    if (_rankController.text.trim().isEmpty) {
      setState(() => _error = 'Rank cannot be empty.');
      return;
    }

    setState(() {
      _isLoading = true;
      _error = null;
    });

    final api = Provider.of<ApiManager>(context, listen: false);
    final response = await api.post(context, 'create_company', {
      'name': _nameController.text.trim(),
      'email': _emailController.text.trim(),
      'rank': _rankController.text.trim(),
    });

    setState(() => _isLoading = false);

    if (response['success']) {
      final companyId = response['data']['company_id'];
      setState(() => infoData['id'] = companyId);
      if (_companyLogo != null) {
        _onImagePicked(_companyLogo, null, 'company');
      }
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => CompanyListPage()),
      );
    } else {
      setState(() => _error = response['message'] ?? 'An error occurred.');
    }
  }

  @override
  Widget build(
    BuildContext context,
  ) {
    final apiManager = Provider.of<ApiManager>(context, listen: false);
    String userImageUrl = infoData['user_image'] != null
        ? "${apiManager.baseUrl}/images/user/user/${infoData['logo']}"
        : "assets/sailorHat.png";
    return CustomScaffold(
      title: 'Create Company',
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Transform.translate(
              offset: const Offset(10, -50),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Row(
                  children: [
                    Column(
                      children: [
                        const SizedBox(height: 50),
                        const Text('Company Logo'),
                        const SizedBox(height: 20),
                        Container(
                          width: 102,
                          height: 102,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            border: Border.all(
                              color: Theme.of(context).colorScheme.primary,
                              width: 3,
                            ),
                          ),
                          clipBehavior: Clip.antiAlias,
                          child: CustomImagePicker(
                            aspectRatio: 1,
                            existingImageUrl: userImageUrl,
                            meta: const {'type': 'user'},
                            onImagePicked: (file, base64) =>
                                _onImagePicked(file, base64, 'user'),
                            iwidth: 100,
                            iheight: 100,
                            iradius: 0,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(width: 20),
                    Expanded(
                      child: TextField(
                        controller: _rankController,
                        decoration: const InputDecoration(
                          labelText: 'Your Rank',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Company Name',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(
                labelText: 'Company E-Mail',
                border: OutlineInputBorder(),
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 8),
              Text(_error!, style: const TextStyle(color: Colors.red)),
            ],
            const SizedBox(height: 20),
            _isLoading
                ? const CircularProgressIndicator()
                : ElevatedButton.icon(
                    onPressed: _submitCompany,
                    icon: const Icon(Icons.check),
                    label: const Text('Save Company'),
                  ),
          ],
        ),
      ),
    );
  }
}
