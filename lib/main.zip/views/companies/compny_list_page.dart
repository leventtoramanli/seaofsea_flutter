import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:seaofsea/utils/api_manager.dart';
import 'package:seaofsea/widgets/custon_scaffold.dart';

class CompanyListPage extends StatefulWidget {
  const CompanyListPage({super.key});

  @override
  State<CompanyListPage> createState() => _CompanyListPageState();
}

class _CompanyListPageState extends State<CompanyListPage> {
  bool _myExpanded = true;
  bool _allExpanded = true;
  List _myCompanies = [];
  List _allCompanies = [];
  int _page = 1;
  final int _limit = 25;
  bool _isLoading = false;
  bool _hasMore = true;
  final ScrollController _scrollController = ScrollController();
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _fetchInitialData();
    _scrollController.addListener(_scrollListener);
  }

  Future<void> _fetchInitialData() async {
    await _fetchMyCompanies();
    await _fetchAllCompanies(reset: true);
  }

  Future<void> _fetchMyCompanies() async {
    final api = context.read<ApiManager>();
    final response = await api.post(context, 'get_user_companies', {});
    if (response['success'] && response['data'] is List) {
      setState(() => _myCompanies = response['data']);
    }
  }

  Future<void> _fetchAllCompanies({bool reset = false}) async {
    if (_isLoading || !_hasMore) return;
    setState(() => _isLoading = true);

    final api = context.read<ApiManager>();
    final response = await api.post(context, 'get_companies', {
      'page': _page,
      'limit': _limit,
      'search': _searchQuery
    });

    if (response['success']) {
      final items = response['data']['items'] as List;
      setState(() {
        if (reset) {
          _allCompanies = items;
          _page = 2;
        } else {
          _allCompanies.addAll(items);
          _page++;
        }
        _hasMore = items.length == _limit;
      });
    }

    setState(() => _isLoading = false);
  }

  void _scrollListener() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 200) {
      _fetchAllCompanies();
    }
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      title: 'Companies',
      body: SingleChildScrollView(
        controller: _scrollController,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton.icon(
                  onPressed: () => Navigator.pushNamed(context, '/create_company'),
                  icon: const Icon(Icons.add_business),
                  label: const Text('Create Company'),
                ),
                ElevatedButton.icon(
                  onPressed: () => Navigator.pushNamed(context, '/join_company'),
                  icon: const Icon(Icons.group_add),
                  label: const Text('Join Company'),
                ),
              ],
            ),
            Divider(),
            ExpansionTile(
              shape: Border.all(color: Colors.transparent),
              title: const Text('Your Companies'),
              initiallyExpanded: _myExpanded,
              onExpansionChanged: (val) => setState(() => _myExpanded = val),
              children: [
                _myCompanies.isEmpty
                    ? const ListTile(title: Text("You don't have any companies."))
                    : Column(
                        children: _myCompanies.map((company) => ListTile(
                          title: Text(company['name'] ?? 'Unnamed'),
                          subtitle: Text('Created at: ${company['created_at']}'),
                        )).toList(),
                      ),
              ],
            ),
            Divider(),
            ExpansionTile(
              shape: Border.all(color: Colors.transparent),
              title: const Text('All Companies'),
              initiallyExpanded: _allExpanded,
              onExpansionChanged: (val) => setState(() => _allExpanded = val),
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: TextField(
                    decoration: const InputDecoration(
                      hintText: 'Search Companies...',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.search),
                    ),
                    onChanged: (value) {
                      _searchQuery = value;
                      _page = 1;
                      _hasMore = true;
                      _fetchAllCompanies(reset: true);
                    },
                  ),
                  
                ),
                Divider(),
                ..._allCompanies.map((company) => ListTile(
                      title: Text(company['name'] ?? 'Unnamed'),
                      subtitle: Text('Created: ${company['created_at']}'),
                    ))
              ],
            ),
            if (_isLoading)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Center(child: CircularProgressIndicator()),
              )
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
}