import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:seaofsea/main.dart';
import 'package:seaofsea/utils/auth_provider.dart';
import 'package:seaofsea/views/admin_dashboard.dart';
import 'package:seaofsea/views/auth/auth_page.dart';
import 'package:seaofsea/views/companies/compny_list_page.dart';
import 'package:seaofsea/views/companies/create_new_compny.dart';
import 'package:seaofsea/views/companies/manage_companies.dart';
import 'package:seaofsea/views/home_page.dart';
import 'package:seaofsea/views/public_profile_page.dart';
import 'package:seaofsea/views/user_settings/settings_page.dart';

Route<dynamic>? generateRoute(RouteSettings settings) {
  switch (settings.name) {
    case '/':
      return MaterialPageRoute(builder: (context) => const MainPage());
    case '/login':
      return MaterialPageRoute(
          builder: (context) => const AuthPage(mode: AuthMode.login));
    case '/register':
      return MaterialPageRoute(
          builder: (context) => const AuthPage(mode: AuthMode.register));
    case '/home':
      return MaterialPageRoute(builder: (context) => const HomePage());
    case '/admin':
      return MaterialPageRoute(builder: (context) => const AdminDashboard());
    case '/settings':
      return MaterialPageRoute(
          builder: (context) => SettingsPage(arguments: settings.arguments));
    case '/public_profile_page':
      return MaterialPageRoute(
          builder: (context) => PublicProfilePage(
                userId: Provider.of<AuthProvider>(context, listen: false)
                    .userInfo?['id'],
              ));
    case '/manage_company':
      return MaterialPageRoute(builder: (context) => const ManageCompanyPage());
    case '/create_company':
      return MaterialPageRoute(builder: (context) => const CreateCompanyPage());
    case '/company_list':
      return MaterialPageRoute(builder: (context) => const CompanyListPage());

    default:
      return MaterialPageRoute(
          builder: (context) => const Center(
                child: Text('Page not found'),
              ));
  }
}

void navigateReplacement(BuildContext context, String routeName,
    {Object? arguments}) {
  Navigator.of(context).pushReplacement(
    generateRoute(RouteSettings(name: routeName, arguments: arguments))!,
  );
}
