import 'package:flutter/foundation.dart';
import 'package:seaofsea/services/v1/v1_api_manager.dart';
import 'package:seaofsea/utils/secure_storage.dart';

class AuthService {
  final V1ApiManager _api = V1ApiManager();
  final SecureStorage _storage = SecureStorage();

  Future<Map<String, dynamic>> login(String email, String password) async {
    final response = await _api.call(
      module: 'auth',
      action: 'login',
      params: {
        'email': email,
        'password': password,
      },
      requiresAuth: false,
    );

    if (response['success'] == true && response['data'] != null) {
      final token = response['data']['token'];
      final user = response['data']['user'];
      final role = user?['role'] ?? 'viewer';

      if (token != null) {
        await _storage.writeSecureData('authToken', token);
        await _storage.writeSecureData('userId', user?['id']?.toString() ?? '');
        await _storage.writeSecureData('role', role);

        if (response['data']['refresh_token'] != null) {
          await _storage.writeSecureData('refreshToken', response['data']['refresh_token']);
        }

        return {
          'success': true,
          'token': token,
          'role': role,
          'user': user
        };
      }
    }

    return {
      'success': false,
      'message': response['message'] ?? 'Login failed'
    };
  }
}
