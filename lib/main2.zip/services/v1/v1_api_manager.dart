import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'package:seaofsea/utils/secure_storage.dart';
import 'v1_config.dart';

class V1ApiManager {
  final String baseUrl;
  final SecureStorage _storage = SecureStorage();

  V1ApiManager({this.baseUrl = V1Config.baseUrl});

  Future<Map<String, dynamic>> call({
    required String module,
    required String action,
    Map<String, dynamic>? params,
    bool requiresAuth = true,
  }) async {
    final uri = Uri.parse('$baseUrl/v1/index.php');

    Map<String, String> headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    // 🛡️ Gerekliyse Authorization ekle
    if (requiresAuth) {
      final token = await _storage.readSecureData('authToken');
      if (token != null && token.isNotEmpty) {
        headers['Authorization'] = 'Bearer $token';
      }
    }

    // ✅ JSON body oluştur
    final body = jsonEncode({
      'module': module,
      'action': action,
      'params': params ?? {},
    });

    if (kDebugMode) {
      print('📤 Sending to $uri');
      print('📨 Headers: $headers');
      print('📨 Body: $body');
    }

    try {
      final response = await http.post(uri, headers: headers, body: body);
      final statusCode = response.statusCode;
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));

      if (kDebugMode) {
        print('📥 Response [$statusCode]: $decoded');
      }

      // ✅ Başarılıysa döndür
      if (statusCode == 200 && decoded['success'] == true) {
        return decoded;
      } else {
        // ❌ API başarısız dönüş
        return {
          'success': false,
          'message': decoded['message'] ?? 'API error',
          'data': decoded['data'],
          'code': statusCode,
        };
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ V1ApiManager Error: $e');
      }
      return {
        'success': false,
        'message': 'Connection error',
        'data': null,
      };
    }
  }
}
