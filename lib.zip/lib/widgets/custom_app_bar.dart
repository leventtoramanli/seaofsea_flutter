import 'package:flutter/material.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final Color backgroundColor;
  final List<Map<String, dynamic>> menuItems;

  const CustomAppBar({super.key, required this.title, required this.backgroundColor, required this.menuItems});

  @override
  Widget build(BuildContext context) {
    final bool wideScreen = MediaQuery.of(context).size.width > 650;

    // Menü öğelerini dinamik olarak alın

    return AppBar(
      title: Text(title, textAlign: wideScreen ? TextAlign.left : TextAlign.center),
      centerTitle: !wideScreen,
      backgroundColor: backgroundColor,
      actions: wideScreen ? _buildActions(menuItems) : null,
    );
  }

  // Geniş ekranda AppBar'a eklenecek aksiyon butonları
  List<Widget> _buildActions(List<Map<String, dynamic>> menuItems) {
    return menuItems.map((item) {
      return IconButton(
        icon: Icon(item['icon']),
        tooltip: item['title'],
        onPressed: item['onTap'],
      );
    }).toList();
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
