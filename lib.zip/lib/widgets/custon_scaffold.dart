import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:seaofsea/utils/auth_provider.dart';
import 'package:seaofsea/utils/theme_provider.dart';
import 'package:seaofsea/utils/theme_selector.dart';

class CustomScaffold extends StatelessWidget {
  final String title;
  final Widget body;
  final bool isAdmin;

  const CustomScaffold({
    super.key,
    required this.title,
    required this.body,
    this.isAdmin = false,
  });

  @override
  Widget build(BuildContext context) {
    final bool wideScreen = MediaQuery.of(context).size.width > 650;
    final AuthProvider authProvider = Provider.of<AuthProvider>(context);
    final LoadingProvider loadingProvider =
        Provider.of<LoadingProvider>(context);
    final List<Map<String, dynamic>> menuItems =
        _getMenuItems(context, authProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text('SeaOfSea - $title'),
        backgroundColor: Theme.of(context).colorScheme.surface,
        actions: [
          ...menuItems.map((item) {
            return IconButton(
              icon: Icon(item['icon']),
              tooltip: item['title'],
              onPressed: item['onTap'],
            );
          }).toList(),
          ThemeSelector(
              themeProvider: Provider.of<ThemeProvider>(context, listen: true)),
        ],
      ),
      drawer: !wideScreen
          ? Drawer(
              child: ListView(
                children: menuItems.map((item) {
                  return ListTile(
                    title: Text(item['title']),
                    leading: Icon(item['icon']),
                    onTap: item['onTap'],
                  );
                }).toList(),
              ),
            )
          : null,
      body: Builder(
        builder: (BuildContext innerContext) {
          return loadingProvider.isLoading
              ? const Center(
                  child: CircularProgressIndicator(),
                )
              : body;
        },
      ),
    );
  }

  List<Map<String, dynamic>> _getMenuItems(
      BuildContext context, AuthProvider authProvider) {
    final List<Map<String, dynamic>> menuItems = [];

    if (authProvider.isLoggedIn) {
      menuItems.add({
        'title': 'Home',
        'icon': Icons.home,
        'onTap': () => Navigator.pushReplacementNamed(context, '/'),
      });

      menuItems.add({
        'title': 'Settings',
        'icon': Icons.settings,
        'onTap': () => Navigator.pushReplacementNamed(context, '/settings'),
      });

      if (authProvider.userInfo?['role'] == 'admin') {
        menuItems.add({
          'title': 'Admin Dashboard',
          'icon': Icons.admin_panel_settings,
          'onTap': () => Navigator.pushReplacementNamed(context, '/admin'),
        });
      }

      menuItems.add({
        'title': 'Profile',
        'icon': Icons.person,
        'onTap': () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('This is a test SnackBar')),
          );
        }
      });

      menuItems.add({
        'title': 'Logout',
        'icon': Icons.logout,
        'onTap': () => authProvider.logout(context),
      });
    }

    return menuItems;
  }
}
