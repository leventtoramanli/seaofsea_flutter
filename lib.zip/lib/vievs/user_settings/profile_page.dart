import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:seaofsea/utils/api_manager.dart';
import 'package:seaofsea/utils/auth_provider.dart';
import 'package:seaofsea/widgets/custom_image_picker.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  File? _coverImage;
  bool _isUploading = false;

  Future<String?> uploadImage(File imageFile) async {
    final apiManager = Provider.of<ApiManager>(context, listen: false);
    final response = await apiManager.uploadImage(
      context,
      endpoint: 'upload_cover_image',
      file: imageFile,
    );
    print('Response before upload: $response');
    if (response['success'] == true) {
      debugPrint('Image uploaded successfully: ${response['message']}${response['data']}');
      return response['data']['file_name'];
    } else {
      debugPrint('Image upload failed: ${response['message']}${response['data']}');
      return null;
    }
  }

  Future<void> updateDatabase(String fileName) async {
    final apiManager = Provider.of<ApiManager>(context, listen: false);
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final userId = authProvider.userInfo!['id'];

    final response = await apiManager.post(
      context,
      'upload_cover_image',
      {
        'user_id': userId,
        'file_name': '$fileName',
      },
    );

    if (response['success'] == true) {
      debugPrint('Database updated successfully: ${response['message']}');
    } else {
      debugPrint('Database update failed: ${response['message']}');
    }
  }

  Future<void> handleImageUpload(File imageFile) async {
    final fileName = await uploadImage(imageFile);
    if (fileName != null) {
      await updateDatabase(fileName);
    }else{
      debugPrint('Image upload failed.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final userId = authProvider.userInfo!['id'];
    final userName = authProvider.userInfo!['name'];
    final userSurName = authProvider.userInfo!['surname'];
    return Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              CustomImagePicker(
                aspectRatio: 4.0,
                meta: {
                  'Publisher': 'Sea of Sea',
                  'Description': 'Cover Image - $userName $userSurName',
                  'Title': 'Cover Image - $userName $userSurName',
                  'Author': 'Sea of Sea',
                  'UserId': userId.toString(),
                },
                onImagePicked: (file) async {
                  print('${authProvider.userInfo}');
                  if (file != null) {
                    setState(() {
                      _coverImage = file;
                    });
                    await handleImageUpload(file);
                  }
                },
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12.0),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black54,
                            blurRadius: 5,
                            offset: Offset(0, 0),
                          ),
                        ]),
                    child: Image.asset(
                      'assets/sailorHat.png',
                      width: 100,
                      height: 100,
                      fit: BoxFit.fitWidth,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Levent TORAMANLI',
                          style: Theme.of(context).textTheme.headlineSmall,
                        ),
                        Text(
                          'Sailor',
                          style: Theme.of(context).textTheme.bodyLarge,
                        ),
                      ],
                    ),
                  ),
                  if (_isUploading) const CircularProgressIndicator()
                ],
              ),
              Divider(
                thickness: 2,
                color: Colors.grey[300],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
