import 'package:flutter/material.dart';
import 'package:seaofsea/widgets/custon_scaffold.dart';

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return const CustomScaffold(
      title: 'Admin Dashboard',
      body: Center(child: Text('Welcome, Admin!')),
    );
  }
}
