// ignore_for_file: use_build_context_synchronously

import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:seaofsea/utils/api_manager.dart';
import 'package:seaofsea/utils/role_provider.dart';
import 'package:seaofsea/utils/secure_storage.dart';
import 'package:seaofsea/views/auth/auth_page.dart';

class AuthProvider with ChangeNotifier {
  String? _authToken;
  String? _role;
  Map<String, dynamic>? _userInfo;
  final bool _isLoadinData = false;

  String? get token => _authToken;
  bool get isLoggedIn => _authToken != null;
  bool get isLoadingData => _isLoadinData;
  Map<String, dynamic>? get userInfo => _userInfo;

  AuthProvider() {
    _loadUserFromPreferences();
  }
  String getRole(BuildContext context) {
    final roleProvider = Provider.of<RoleProvider>(context, listen: false);
    final int roleId = int.tryParse(_role ?? '') ?? 3;
    return roleProvider.getRoleNameById(roleId);
  }

  String generateUUID() {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    final random = Random();
    return List.generate(36, (index) {
      if (index == 8 || index == 13 || index == 18 || index == 23) {
        return '-'; // UUID formatına uygun tireler
      }
      return chars[random.nextInt(chars.length)];
    }).join();
  }

  Future<String> saveDeviceUUID() async {
    final storage = SecureStorage();
    String? deviceUUID = await storage.readSecureData('deviceUUID');

    if (deviceUUID == null || deviceUUID.isEmpty) {
      deviceUUID = generateUUID();
      await storage.writeSecureData('deviceUUID', deviceUUID);
    }
    return deviceUUID;
  }

  Future<void> login(BuildContext context, String token, String role) async {
    _authToken = token;
    _role = role;
    _userInfo = _decodeToken(token); // ✅ Token decode ediliyor
    notifyListeners();

    final storage = SecureStorage();

    // ✅ `user_id`yi hem token'dan hem de doğrudan API'den almak için güvenli kontrol
    String? userId = _userInfo?['id']?.toString();
    userId ??= await storage.readSecureData('userId');

    if (userId != null) {
      await storage.writeSecureData('userId', userId);
    } else {
      debugPrint('🛑 Warning: user_id is NULL!');
    }

    await storage.writeSecureData('authToken', token);
    await storage.writeSecureData('role', role);

    if (_userInfo != null && _userInfo!.containsKey('refresh_token')) {
      await storage.writeSecureData(
          'refreshToken', _userInfo!['refresh_token']);
      debugPrint("✅ Refresh token kaydedildi: ${_userInfo!['refresh_token']}");
    }
  }

  Future<void> logout(BuildContext context, {bool allDevices = false}) async {
    if (!context.mounted) {
      return; // 🔥 Eğer context kullanılamıyorsa, logout'u çalıştırma
    }
    try {
      final storage = SecureStorage();
      final refreshToken = await storage.readSecureData('refreshToken');
      final deviceUUID = await storage.readSecureData('deviceUUID');

      if (refreshToken != null && deviceUUID != null) {
        final apiManager = Provider.of<ApiManager>(context, listen: false);
        await apiManager
            .request(context, endpoint: 'logout', method: 'POST', body: {
          'refresh_token': refreshToken,
          'device_uuid': deviceUUID,
          'all_devices': allDevices
        });
      } else {
        debugPrint('No refreshToken or deviceUUID found');
      }

      // ✅ SecureStorage içindeki tüm verileri temizle
      await storage.deleteSecureData('authToken');
      await storage.deleteSecureData('refreshToken');
      await storage.deleteSecureData('role');
      await storage.deleteSecureData('userId');
      debugPrint(
          "✅ Logout sonrası token: ${await storage.readSecureData('authToken')}");

      // ✅ AuthProvider değişkenlerini sıfırla
      _authToken = null;
      _role = null;
      _userInfo = null;

      // ✅ UI'yı güncelle
      notifyListeners();

      debugPrint("✅ Kullanıcı başarıyla çıkış yaptı.");

      // ✅ Kullanıcıyı login sayfasına yönlendir
      if (context.mounted) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
              builder: (context) => const AuthPage(mode: AuthMode.login)),
          (route) => false,
        );
      }
    } catch (e) {
      debugPrint('❌ Logout sırasında hata oluştu: $e');
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Logout failed: $e')),
        );
      }
    }
  }

  Future<void> validateToken(BuildContext context) async {
    final storage = SecureStorage();
    final refreshToken = await storage.readSecureData('refreshToken');
    try {
      if (refreshToken == null) {
        await logout(context);
        return;
      }

      final apiManager = Provider.of<ApiManager>(context, listen: false);
      final isValid = await apiManager.request(context,
          endpoint: 'check_token',
          method: 'POST',
          body: {'refresh_token': refreshToken});

      if (!isValid['success']) {
        await logout(context);
      } else {
        debugPrint('Token is valid.');
      }
    } catch (e) {
      debugPrint('Error during token validation: $e');
      if (context.mounted) {
        if (ScaffoldMessenger.maybeOf(context) != null) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Token validation failed')),
          );
        }
        await logout(context); // Herhangi bir hata durumunda logout yap
      }
    }
  }

  Future<void> _loadUserFromPreferences() async {
    final storage = SecureStorage();
    _authToken = await storage.readSecureData('authToken');
    _role = await storage.readSecureData('role');
    await saveDeviceUUID();

    if (_authToken != null) {
      _userInfo = _decodeToken(_authToken!);
    } else {
      _userInfo = null;
    }

    // Notify listeners after loading user data
    notifyListeners();
  }

  Map<String, dynamic>? _decodeToken(String token) {
    try {
      final parts = token.split('.');
      if (parts.length != 3) {
        throw Exception('Invalid token format.');
      }
      final payload =
          utf8.decode(base64Url.decode(base64Url.normalize(parts[1])));
      return jsonDecode(payload)['data'];
    } catch (e) {
      debugPrint('Error decoding token: $e');
      return null;
    }
  }

  Future<void> refreshUserInfo(BuildContext context) async {
    final apiManager = Provider.of<ApiManager>(context, listen: false);
    try {
      final response = await apiManager.get(context, 'get_user_info');
      if (response['success'] == true) {
        _userInfo = response['data'];
        final secureStorage = SecureStorage();
        await secureStorage.writeSecureData('userId', _userInfo?['id']);
        await secureStorage.writeSecureData('email', _userInfo?['email']);
        await secureStorage.writeSecureData('name', _userInfo?['name']);
        await secureStorage.writeSecureData('surname', _userInfo?['surname']);
        await secureStorage.writeSecureData(
            'coverImage', _userInfo?['cover_image']);
        await secureStorage.writeSecureData('user_image', _userInfo?['user_image']);
        notifyListeners();

        debugPrint('✅ User info refreshed successfully: $_userInfo');
      } else {
        throw Exception(response['message']);
      }
    } catch (e) {
      debugPrint('⚠️ Error refreshing user info: $e');
    }
  }
}

class LoadingProvider with ChangeNotifier {
  bool _isLoading = false;

  bool get isLoading => _isLoading;

  void setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}
